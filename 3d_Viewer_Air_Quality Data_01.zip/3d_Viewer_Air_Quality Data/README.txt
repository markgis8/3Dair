3d viewer of air quality data.
This demo project is developed with Nasa World Wind 1.5, Java 1.7, Eclipse 4.2 Juno paltform on Windows 64-bit system.

To launch the program click start.bat in the folder 3d_Viewer_Air_Quality. 

In the folder florence pm10 csv.zip you'll find a simple csv example file, created using the opendata in accordance with  Directive 2003/4/CE and Italian L. 18 Dicembre 2012 and D.L. 18.10.2012, n. 179. The data are published on http://www.datiopen.it/it/opendata/Comune_di_Firenze_Agenti_inquinanti_ARPAT, and http://osservatorioambientale.nododifirenze.it/.

The folder florence shapefile contains the shapefile of buildings. It was extracted from http://www.openstreetmap.org/ on May 2013. The dbf contains two fields named UN_VOL_AV and height. They are used as a test, they do not refer to real height of the buildings. OpenStreetMap is covered by Open Data Commons Open Database License (ODbL) and this cartography is licensed under CC-BY-SA 2.0.� OpenStreetMap contributors.

The folder 3d_Viewer_Air_Quality_Data_Source contains the source file. 

The software is developed in accordance with NASA_Open_Source_Agreement_1.3

University of Padua
CIRGEO, Interdepartmental Research Center on Cartography, Photogrammetry, Remote Sensing and 
GIS University of Padua, viale dell�Universit�, 16 35020 Legnaro.
� 28/05/2013
V 0.1
Author: Marco Piragnolo
marco.piragnolo@unipd.it  or mark_pir@yahoo.it