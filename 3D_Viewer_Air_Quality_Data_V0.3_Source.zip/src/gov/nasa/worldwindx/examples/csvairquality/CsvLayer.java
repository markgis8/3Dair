package gov.nasa.worldwindx.examples.csvairquality;

import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.*;
import java.lang.Math;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import delaunay_triangulation.Delaunay_Triangulation;
import delaunay_triangulation.Point_dt;
import delaunay_triangulation.Triangle_dt;
import java.util.Iterator;

 
/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * This class creates the geometries from the csv file
 * It reads the csv's points positions and creates the polygons using a Delaunay triangulation 
 * It also creates a limit layer
 * @author Marco Piragnolo Cirgeo, Francesco Pirtotti, University of Padua, marco.piragnolo@unipd.it, francesco.pirotti@unipd.it
 * @version 0.3 PointInterpolator 2014-22-01 15:28
 */

/**Applying the triangulation class it creates csv layer with air quality polygons and limit plane*/
public class CsvLayer { 
	protected gov.nasa.worldwindx.examples.csvairquality.ShpLoader3D.AppFrame appFrame;
	int np;
	double xxa,xxb,xxc,yya,yyb,yyc,zza,zzb,zzc;
	double average;
   // static private  Interpolator2D  interp ;

	// FP
    static private MakeRaster rasterObj;
    // FP
	private Triangle_dt _t1, _t2; // tmp triangle 
	private Delaunay_Triangulation _ajd = null;
	private Iterator<Triangle_dt> it = null;
	// FP
	/**Creates the layer for extruded polygon and layer for limit*/
	public List<Layer> csvLayer(Object source, int day, int vexa, boolean limitlay ) throws IOException {

			// Create the layer where you will place your polygons
			RenderableLayer layer = new RenderableLayer();
			 
			CsvEmReader csv = new CsvEmReader();
		
			//index for while loop that creates placemarks
			int index=0;
			//declare the arrays that contain the values of x,y
			double x[] = csv.getCsvX();
			double y[] = csv.getCsvY();		
			//change this number to change the day of view
			double z[] = csv.getCsvZD(day);	
		
			
			String name[] = csv.getNamePoint();	
			String onedatename[] = csv.getOneDateName(day);

			//number of points form csv file ???
			np = csv.getNumberPoint();					
			
			//average value form the three points that are the vertices of the polygon
			 average = 0.0;
				
			 //creates and set the placemark
			while (index < np)
			{
				

				PointPlacemark pm1 = new PointPlacemark((Position.fromDegrees(y[index],x[index],z[index]*(vexa/5))));				
				//set altitde mode as absolute
				pm1.setAltitudeMode(0);										
				//Placemark attribute
				PointPlacemarkAttributes pointAttribute1 = new PointPlacemarkAttributes();				
				//Attaching the placemark attributes to the placemarks.
				pm1.setAttributes(pointAttribute1);					
				// Changing font type, size and setting it to bold.			
				pointAttribute1.setLabelFont(Font.decode("Calibri-Bold-22"));				
				//Changing color of the placemarkers and label color
				if(1<z[index] && z[index]<=35)
				{
				pointAttribute1.setImageColor(Color.yellow);
				pointAttribute1.setLabelMaterial(Material.YELLOW);	
				}
				else if (35<z[index] && z[index]<=50)
				{
				pointAttribute1.setImageColor(Color.orange);
				pointAttribute1.setLabelMaterial(Material.ORANGE);
				}
				else if (z[index]>50)
				{
				pointAttribute1.setImageColor(Color.red);	
				pointAttribute1.setLabelMaterial(Material.RED);
				}
				else
				{
				pointAttribute1.setImageColor(Color.gray);	
				pointAttribute1.setLabelMaterial(Material.GRAY);
				}										
				//Setting text label for placemarkers. The name is got by the array
				pm1.setLabelText(name[index]);				
				//Setting up annotation pop-up to be activated with mouse-over. The value is got by the array
				String value2 = String.valueOf(z[index]);			
				pm1.setValue(AVKey.DISPLAY_NAME, value2+" �g/m3");								
				//add point mark to layer
				layer.addRenderable(pm1);
				index++;
			}

			
			{	
				int a=0;
				int b=0;
				int c=0;

			_ajd = new Delaunay_Triangulation();

			for (int i = 0; i < np; i++)
		    {
				Point_dt q = new Point_dt(x[i], y[i], z[i]);
				_ajd.insertPoint(q);				
		    }
			
			double widthInMeters = (max(x) - min(x));
			double heightInMeters = max(y) -  min(y);
			double scaleToMeterPixel=0;
			// Window is in meteres. I resize, to have the max lenght of side is 100 pixel. 
			// In fact, estimating a side 10x longer than we would have 1000 x 100 pixels 100,000 pixels == ... can go well as rendering speed?? we'll see
 
			if(widthInMeters > heightInMeters)
				scaleToMeterPixel = 1.0/heightInMeters * 100.0;
			else
				scaleToMeterPixel = 1.0/widthInMeters * 100.0;
			// 1 / scaleToMeterPixel = one pixel dimension!
			System.out.println("height raster:"+String.valueOf( heightInMeters )  +
					" -- width:" + String.valueOf(widthInMeters) + " -- scale " + String.valueOf(scaleToMeterPixel) 
					+ " -- pixelSize " + String.valueOf((1.0/scaleToMeterPixel)));
			
			// Preepare the iterator that pass all triangles
			it = _ajd.trianglesIterator();
			// I pass to MakeRaster all elements
			rasterObj = new MakeRaster( (int)Math.ceil(widthInMeters*scaleToMeterPixel),  
					(int)Math.ceil(heightInMeters*scaleToMeterPixel), 
					min(x), max(y), 1.0/scaleToMeterPixel, 	min(z), max(z), _ajd );
			

		    //**********  HERE I CREATED THE RASTER INTERPOLATING POINTS! WINDOW I HAVE TO RASTER "REALWINDOW" ABOVE  *****************
						            
			Triangle_dt t = null;
			it = _ajd.trianglesIterator();
			while (it.hasNext()) {
				t = it.next(); 	 

				if(t.isHalfplane()) continue;
				 int index2=0; //index to extract the name of each day
				 xxa = t.p1().x(); 
				 yya=  t.p1().y();
				 zza=  t.p1().z();

				 xxb = t.p2().x(); 
				 yyb=  t.p2().y();
				 zzb=  t.p2().z();				 

				 xxc = t.p3().x(); 
				 yyc=  t.p3().y();
				 zzc=  t.p3().z();
			   	    
				ArrayList<Position> positionsN = new ArrayList<Position>();
				positionsN.add(Position.fromDegrees(yya,xxa,zza*(vexa/5)));
				positionsN.add(Position.fromDegrees(yyb,xxb,zzb*(vexa/5)));
				positionsN.add(Position.fromDegrees(yyc,xxc,zzc*(vexa/5)));
				positionsN.add(Position.fromDegrees(yya,xxa,zza*(vexa/5)));
				
				// ExtrudedPolygon poly = new ExtrudedPolygon(positions);
				ExtrudedPolygon polyN = new ExtrudedPolygon(positionsN);				
				// set the polygon�s altitude relative to ground
				polyN.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);				
				// set polygon color 			
	            ShapeAttributes sideAttributesN = new BasicShapeAttributes();
	            sideAttributesN.setOutlineOpacity(0.5);
	            sideAttributesN.setInteriorOpacity(0.3);
	            sideAttributesN.setOutlineMaterial(Material.BLACK);
	            sideAttributesN.setOutlineWidth(1);
	            sideAttributesN.setDrawOutline(true);
	            sideAttributesN.setDrawInterior(false);
	            sideAttributesN.setEnableLighting(false);
	          
	            ShapeAttributes sideHighlightAttributesN = new BasicShapeAttributes(sideAttributesN);           
	            sideHighlightAttributesN.setOutlineOpacity(0.3);
	            sideAttributesN.setInteriorMaterial(Material.WHITE);
	            sideHighlightAttributesN.setOutlineMaterial(Material.WHITE);
	            
	            ShapeAttributes capAttributesN = new BasicShapeAttributes(sideAttributesN);
	            capAttributesN.setInteriorOpacity(0.4);
	            capAttributesN.setDrawInterior(false);
	            capAttributesN.setEnableLighting(false);	  
	            
	            double av=(zza+zzb+zzc)/3;
	            average=this.rounding(av, 3);
	            double variance=(Math.pow(((zza-av)/3), 2)+Math.pow(((zzb-av)/3), 2)+Math.pow(((zzc-av)/3), 2));
	            double sqrt=this.rounding(Math.sqrt(variance),3);
	            
	   	     /*       
	            if( average<=35 )
	            {
	          //  sideAttributesN.setInteriorMaterial(Material.CYAN);	
	            //sideHighlightAttributesN.setOutlineMaterial(Material.CYAN);
	            capAttributesN.setInteriorMaterial(Material.CYAN);
	            }
	            else if( 35<average && average<=50 )
	            {
	          // sideAttributesN.setInteriorMaterial(Material.YELLOW);	
	           // sideHighlightAttributesN.setOutlineMaterial(Material.YELLOW);
	            capAttributesN.setInteriorMaterial(Material.YELLOW);
	            }	
	            else if( average>50 )
	            {
	          //  sideAttributesN.setInteriorMaterial(Material.RED);	
	           // sideHighlightAttributesN.setOutlineMaterial(Material.RED);
	            capAttributesN.setInteriorMaterial(Material.RED);
	            }	
	            else
	            {
	          // sideAttributesN.setInteriorMaterial(Material.GRAY);	
	           // sideHighlightAttributesN.setOutlineMaterial(Material.GRAY);
	            capAttributesN.setInteriorMaterial(Material.GRAY);
	            }	 
	     */             
				
	            // Tooltip polygon attribute
				polyN.setSideHighlightAttributes(sideHighlightAttributesN);
				polyN.setSideAttributes(sideAttributesN);
				polyN.setCapAttributes(capAttributesN);
				polyN.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);

				//set the text in the polygon
				polyN.setValue(AVKey.DISPLAY_NAME,"<br> Date: "+onedatename[index2]+"<br>Polygon: "+name[a]+"_"+name[b]+"_"+name[c]+"<br>average: "+average+ " �g/m3"+ "<br>standard deviation: "+sqrt);
										
				layer.addRenderable(polyN);
				
				ShpLoader3D.WorkerThread.getAppFrame();
				ShpLoader3D.WorkerThread.getTerrain();
				PointInterpolator newmap=new PointInterpolator();
				newmap.insertGrid(positionsN,  ShpLoader3D.WorkerThread.getAppFrame());
				newmap.insertLine(yya, xxa, zza, yyb, xxb, zzb, yyc, xxc, zzc, polyN, ShpLoader3D.WorkerThread.getAppFrame(), 1.0);			
				newmap.insertPoint(yya, xxa, zza, yyb, xxb, zzb, yyc, xxc, zzc, polyN, ShpLoader3D.WorkerThread.getAppFrame(), 1.0);	
				newmap.insertPointFill(yya, xxa, zza, yyb, xxb, zzb, yyc, xxc, zzc, polyN, ShpLoader3D.WorkerThread.getAppFrame(), 0);	
				index2++;
				}		
			}
			
	
			// Creates the limit layer
			ShapeAttributes normalAttributes = new BasicShapeAttributes();

			normalAttributes.setInteriorMaterial(Material.BLACK);
			normalAttributes.setInteriorOpacity(1);
			normalAttributes.setOutlineWidth(1);           
			normalAttributes.setDrawInterior(true);
			normalAttributes.setDrawOutline(true);
			normalAttributes.setEnableLighting(false);
			
			ArrayList<Position> positions = new ArrayList<Position>();
							
			positions.add(Position.fromDegrees(min(y),min(x),50*(vexa/5)));
			positions.add(Position.fromDegrees(min(y),max(x),50*(vexa/5)));
			positions.add(Position.fromDegrees(max(y),max(x),50*(vexa/5)));
			positions.add(Position.fromDegrees(max(y),min(x),50*(vexa/5)));
			positions.add(Position.fromDegrees(min(y),min(x),50*(vexa/5)));
			
			Polygon polyl = new Polygon(positions);

			// set the polygon�s altitude relative to ground
			polyl.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
			polyl.setAttributes(normalAttributes);		
			polyl.setHighlighted(false);
				
			polyl.setValue(AVKey.DISPLAY_NAME, "Limit value (DM 60/2002): 50 �g/m3");
			polyl.setVisible(limitlay);
			layer.addRenderable(polyl); 					
			List<Layer> layers = new ArrayList<Layer>();
			
			layers.add(layer);
			return layers;			
		}
	
	 /**Calculate the round to three decimal */
	 public double rounding(double value, int decimalPlace){	        
	        double factor = (double) Math.pow(10d, decimalPlace);
	        double roundValue =  Math.round(value*factor)/factor;	        
	        return roundValue;
	  }
		
	  /**Find the min value*/
	  public static double min(double[] array) {
	      // Validates input
	      if (array == null) {
	          throw new IllegalArgumentException("The Array must not be null");
	      } else if (array.length == 0) {
	          throw new IllegalArgumentException("Array cannot be empty.");
	      }	  
	      // Finds and returns min
	      double min = array[0];
	      for (int i = 1; i < array.length; i++) {
	          if (Double.isNaN(array[i])) {
	              return Double.NaN;
	          }
	          if (array[i] < min) {
	              min = array[i];
	          }
	      }	  
	      return min;
	  }

	  /**Find the max value*/
	  public static double max(double[] array) {
	      // Validates input
	      if (array == null) {
	          throw new IllegalArgumentException("The Array must not be null");
	      } else if (array.length == 0) {
	          throw new IllegalArgumentException("Array cannot be empty.");
	      }
  
	      // Finds and returns min
	      double max = array[0];
	      for (int i = 1; i < array.length; i++) {
	          if (Double.isNaN(array[i])) {
	              return Float.NaN;
	          }
	          if (array[i] > max) {
	        	  max = array[i];
	          }
	      }	  
	      return max;
	  	}
	  
	  /**Gets the length of the base in order to calculate the height of point of view*/
	  public double getCsVBase() throws IOException 
	  {	
			CsvEmReader csv = new CsvEmReader();
			double x[] = csv.getCsvX();
			double y[] = csv.getCsvY();			
			LatLon p1=LatLon.fromDegrees(min(x), min(y));
			LatLon p2=LatLon.fromDegrees(max(x), max(y));
			double lenght = LatLon.ellipsoidalDistance(p1, p2, 6378.1, 6356.8) * 1000; 
			//from http://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html																			
			return lenght;		
	  }
		
	  /**Gets the central position  longitude*/
	  public double getCsvCentreLon() throws IOException 
	  {			
			CsvEmReader csv = new CsvEmReader();
			double x[] = csv.getCsvX();
			double centreLon =  ((max(x)+min(x))/2);
			return centreLon;
	  }	

	  /**Gets the central position  latitude*/
	  public double getCsvCentreLat() throws IOException 
	  {
			CsvEmReader csv = new CsvEmReader();
			double y[] = csv.getCsvY();
			double centreLat = ((max(y)+min(y))/2);
			return centreLat;
	  }	
		
	  
	public static void main(String[] args) {
	}
}