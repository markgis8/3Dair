package gov.nasa.worldwindx.examples.csvairquality;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * Draws a grid of points on the terrain. The points are evenly spaced throughout a region defined by a four sided
 * polygon.
 * @version $Id: GridOfPoints.java 1 2011-07-16 23:22:47Z dcollins $
 * Modified by
 * @author Francesco Pirotti Cirgeo, University of Padua, francesco.pirotti@unipd.it
 * @version 0.3 PointInterpolator 2014-22-01 15:28
 */
/**Create a raster from using coordinates of a plane*/
 

import java.awt.Color;
import java.awt.image.BufferedImage; 
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
 
//FP
import delaunay_triangulation.Delaunay_Triangulation;
import delaunay_triangulation.Point_dt;
import delaunay_triangulation.Triangle_dt;

import javax.imageio.ImageIO;

public class MakeRaster
{	  
	 
    int opIndex;
    static private BufferedImage bi, biFiltered; 
    // Width and Height set at main function!
    static int w, h;
    static double s, t;
    static Point_dt pt;
    // FP coordinate XY origin
    static double oriX, oriY;
    // FP pixel dimension (normally x==y)
    static double scaleX, scaleY;
	Color myWhite = new Color(55, 0, 0);
     
	// Giving the x and y coordinate origin (top right) and number of rows and columns and resolution
	// Draws up a plan with the values ​​at the center of the cell that correspond
	// Intersection on the triangle (if there is no triangle provides null)
	public MakeRaster(int width, int height, 
			double oriXin, double oriYin, double scaleXY,  
			double minZ, double rangeZ, Delaunay_Triangulation it) // args[0]=width
	{
		//MakeRaster r = new MakeRaster();
		w=width; h=height;
		oriX=oriXin; oriY=oriYin;
		scaleY=scaleX=scaleXY; 

		// prepare the place for the Z value
		Double zValueFromTriangle = null; 
		// triangles iterator 
		Iterator<Triangle_dt> iterat = null;
		// triangles
		Triangle_dt t = null;
		// point xy
		Point_dt pt = new Point_dt();
		// buffer  dell'imagine
        bi =   new BufferedImage(w, h,
                          BufferedImage.TYPE_INT_RGB); 
        
        // Here I make the loop for each column and each row
        for(int c= 0; c< w; c++)
        {
            for(int r= 0; r< h ; r++)
            { 
            	// I provide X and Y of the center of the cell to the point
            	pt.setX( oriX + (scaleX*c) + (0.5*scaleX) ); // FP 0.5 perchè prendiamo il valore centrale della cella
        	    pt.setY( oriY - (scaleY*r) - (0.5*scaleY) ); // FP 0.5 perchè prendiamo il valore centrale della cella
        	    // iterator 
        		iterat = it.trianglesIterator();
        	
      	    zValueFromTriangle = null;
      	    // traingles loop
			while (iterat.hasNext()) {
				t = iterat.next(); 
				// if the point is contained within the triangle consierato, I take the Z coordinate XY
				if(t.contains(pt))
				{
					zValueFromTriangle = t.z_value(pt);
					// exit because you do not need to continue if it has been assigned the Z
					break;
				}
			} 

			// It is possible that the point does not fall in any triangle
			// In that case I do not provide a value
			// Otherwise I provide the color according to a linear scale green/red
			
        if(zValueFromTriangle!=null)	
        	{       	
        	bi.setRGB(c, r, new Color(  (int) (  (1.0 - (zValueFromTriangle - minZ)/rangeZ)*255.0),     (int) ( ( (zValueFromTriangle - minZ)/rangeZ)*255.0) , 0).hashCode() );
        
        	System.out.println("col="+String.valueOf(c)+" row="+String.valueOf(r) +" s =  " +  String.valueOf(s) +
        			"  t =  " +  String.valueOf(t) + 
        			"  vo =  " +  String.valueOf(zValueFromTriangle) );
        	
        	}
    	//usage
    	//same with other demonstrations.	   	 
            }             
        }
        try { 
        	// save the image!
            File outputfile = new File("D:\\saved.png");
            ImageIO.write(bi, "png", outputfile);
        } catch (IOException e) {
         
        	System.out.println("ERRORE!!!   " +  e.toString());
			
        }
        //new interpolator does not require another beginning ...
        //must be added to the values ​​with 2D coordinates and values ​​("Z") at the interpolator
        
	}
	
	public float linearInterpolation(float start, float end, float normalizedValue) {
	    return start + (end - start) * normalizedValue;
	}

	public double sinInterpolation(float start, float end, float normalizedValue){
	    return (start+(end-start)* (1 - Math.cos(normalizedValue * Math.PI)) / 2);
	}

}


