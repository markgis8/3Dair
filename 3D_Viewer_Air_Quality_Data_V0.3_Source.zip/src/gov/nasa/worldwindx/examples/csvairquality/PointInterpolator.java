package gov.nasa.worldwindx.examples.csvairquality;

/*
Copyright (C) 2001, 2010 United States Government
as represented by the Administrator of the
National Aeronautics and Space Administration.
All Rights Reserved.
*/


import gov.nasa.worldwind.Configuration;
import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwindx.examples.ApplicationTemplate;
import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.Intersection;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Line;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Vec4;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Path;
import gov.nasa.worldwind.render.PointPlacemark;
import gov.nasa.worldwind.render.PointPlacemarkAttributes;
import gov.nasa.worldwind.render.Polygon;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwind.terrain.HighResolutionTerrain;
import gov.nasa.worldwind.util.UnitsFormat;
import gov.nasa.worldwind.util.measure.MeasureToolController;

import java.awt.Color;
import java.util.*;

import javax.swing.JOptionPane;


/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * Draws a grid of points on the terrain. The points are evenly spaced throughout a region defined by a four sided
 * polygon.
 * @version $Id: GridOfPoints.java 1 2011-07-16 23:22:47Z dcollins $
 * Modified by
 * @author Marco Piragnolo Cirgeo, University of Padua, marco.piragnolo@unipd.it
 * @version 0.3 PointInterpolator 2014-22-01 15:28
 */
/**Create intersection, called interpolator, from ground point to polygon surface's point */


public class PointInterpolator extends ApplicationTemplate
{

    protected static int NUM_POINTS_WIDE2;
    protected static int NUM_POINTS_HIGH2;
    protected static int gridsWIDE = 100;
    protected static int gridsHIGH = 100;
    protected static String xmeter;
    protected static String totalinterp;
    
    //this is the index of each layerPoint added to the appframe
    static int indexLayerPoint = 0;
    
    List<Position> positions = new ArrayList<Position>(NUM_POINTS_WIDE2 * NUM_POINTS_WIDE2);
    
    protected RenderableLayer layer; // layer to display the polygon and the intersection

    protected Polygon polygon; // the polygon to intersect
    
    protected HighResolutionTerrain terrain= ShpLoader3D.WorkerThread.getTerrain(); 
    
    //index for total intepolation layer
    static int totalintepolation=0;
    
    PointPlacemark intersectionPointPlacemark;
    PointPlacemark intersectionPointPlacemarkFill;
    
        public  PointPlacemark getColorMap(Position position, ExtrudedPolygon extPoly, AppFrame appFrame, double factor)
        {             	
        	try
            {
                // Create the line to intersect with the shape.
                Position referencePosition = position;

                Vec4 referencePoint = terrain.getSurfacePoint(referencePosition);

                Position targetPosition = new Position(referencePosition, 1e3);
               
                Vec4 targetPoint = terrain.getSurfacePoint(targetPosition);
                
                Line line = new Line(targetPoint, referencePoint.subtract3(targetPoint));

                // Perform the intersection.
                List<Intersection> intersections = extPoly.intersect(line, terrain);
                             
                // Get and display the intersections.
                if (intersections != null)
                {	
                	//drawInteresctionMarker(intersections); 
                    for (Intersection intersection : intersections)
                    {                        	                 	                    	
                    	intersectionPointPlacemark=drawIntersection(intersection, appFrame); 
                    	intersectionPointPlacemarkFill=drawIntersectionFill(position, intersection, intersections, appFrame, factor); 
                    
                    	totalintepolation++;
                    	totalinterp=""+totalintepolation;
                        System.out.println("Points interpolated : "+totalintepolation); 
                    }            
                }                
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }		
			return  intersectionPointPlacemark;       	
        }
        
        public  PointPlacemark getColorMapFill(Position position, ExtrudedPolygon extPoly, AppFrame appFrame, double factor)
        {             	
        	try
            {
                // Create the line to intersect with the shape.
                Position referencePosition = position;

                Vec4 referencePoint = terrain.getSurfacePoint(referencePosition);

                Position targetPosition = new Position(referencePosition, 1e3);
               
                Vec4 targetPoint = terrain.getSurfacePoint(targetPosition);
                
                Line line = new Line(targetPoint, referencePoint.subtract3(targetPoint));

                // Perform the intersection.
                List<Intersection> intersections = extPoly.intersect(line, terrain);
                        
                // Get and display the intersections.
                if (intersections != null)
                {	
                	//drawInteresctionMarker(intersections); 
                    for (Intersection intersection : intersections)                   	
                    {                    	                 	                 	                    	
                    	intersectionPointPlacemarkFill=drawIntersectionFill(position, intersection, intersections, appFrame, factor);                  
                    	totalintepolation++;
                    	totalinterp=""+totalintepolation;
                        System.out.println("Points interpolated : "+totalintepolation); 
                    }            
                }                
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }		
			return  intersectionPointPlacemarkFill;       	
        }
        
                
        @SuppressWarnings("null")
		public List<Position> getIntersectionsListPosition(Position position)
        {
        	List<Intersection> intersections = null;
        	List<Position> poslist = null;
        	try
            {
                // Create the line to intersect with the shape.
                Position referencePosition = position;
                Vec4 referencePoint = terrain.getSurfacePoint(referencePosition);

                Position targetPosition = new Position(referencePosition, 10);
                Vec4 targetPoint = terrain.getSurfacePoint(targetPosition);
                Line line = new Line(targetPoint, referencePoint.subtract3(targetPoint));

                // Perform the intersection.
                intersections = this.polygon.intersect(line, terrain);
                for (Intersection intersectionI : intersections)
                {          	
                	Position poscicle1 = new Position(intersectionI.getIntersectionPosition().getLatitude(), intersectionI.getIntersectionPosition().getLongitude(), intersectionI.getIntersectionPosition().getElevation()*0.25);
                	Position poscicle2 = new Position(intersectionI.getIntersectionPosition().getLatitude(), intersectionI.getIntersectionPosition().getLongitude(), intersectionI.getIntersectionPosition().getElevation()*0.50);
                	Position poscicle3 = new Position(intersectionI.getIntersectionPosition().getLatitude(), intersectionI.getIntersectionPosition().getLongitude(), intersectionI.getIntersectionPosition().getElevation()*0.75);
                	poslist.add(poscicle1);            	
                }
                
            } 
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        	
        	System.out.println("******: "+poslist);
        	return poslist;
        }      
        
        public static Color interpolateColor(Color from, Color to, double factor)
        {	
            return new Color(
            	(int) (from.getRed() * factor + to.getRed() * (1 - factor)),
                (int) (from.getGreen() * factor + to.getGreen() * (1 - factor)),
                (int) (from.getBlue() * factor + to.getBlue() * (1 - factor)),
                (int) (from.getAlpha() * factor + to.getAlpha() * (1 - factor)));            
        }
        
        protected PointPlacemark drawIntersection(Intersection intersection, AppFrame appFrame)
        { 	     	
        	
           //Display a point at the intersection.     	
            PointPlacemark iPoint = new PointPlacemark(intersection.getIntersectionPosition());          
            iPoint.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
            PointPlacemarkAttributes pointAttributes = new PointPlacemarkAttributes();
           
            /* 
        	//THIS IS A SIMPLE COLOR          
            if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=35)
            {
            	double factor=(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5))/255;           	
            	pointAttributes.setLineMaterial(Material.GREEN);
            }
            else if(intersection.getIntersectionPosition().getElevation()>35 && intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=50)
            {
            	double factor=(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5))/255;           	
            	pointAttributes.setLineMaterial(Material.CYAN);
            }
            else if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)>50)
            {
            	pointAttributes.setLineMaterial(Material.BLUE);           	
            }
            */
                    
	        // THIS IS A GRADIENT COLOR
	        //Color for gradient
	    	Color brown = new Color(210, 63, 50);
	    	Color gold = new Color(210, 100, 50);
	    	Color lightG = new Color(210, 137, 32);
	    	Color lightY = new Color(255, 230, 192);
	        	   
	        if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=35)
	        {
	            double factor1=(Math.abs(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)/50));

	            pointAttributes.setLineMaterial( new Material(interpolateColor(lightG,lightY, factor1)));
	        }
	        else if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/50)>35 && intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=50)
	        {
	            double factor2=(Math.abs(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5))/50);

	            pointAttributes.setLineMaterial(new Material(interpolateColor (gold, lightY, factor2)));
	        }
	        else if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)>50)
	        {	          
	            pointAttributes.setLineMaterial(new Material (interpolateColor(brown, gold, 1)));	
	            //pointAttributes.setLineMaterial( Material.RED);	  
	        }
	      	                   
            pointAttributes.setUsePointAsDefaultImage(true);
            iPoint.setAttributes(pointAttributes);               
			return iPoint;
        }
       
        
        
        @SuppressWarnings("null")
		protected PointPlacemark drawIntersectionFill(Position position, Intersection intersection, List<Intersection> intersections, AppFrame appFrame, double factor)
        { 	

        	PointPlacemark iPoint2 = null;
        	System.out.println("intersection "+intersection.getIntersectionPosition());
        	System.out.println("intersectionS "+intersections.size());
        	List<Intersection> intersectionlist= null;
        	List<Position> poslist = new ArrayList<Position>();
        	for (Intersection intersectionI : intersections)
			{       	
				Position poscicle1 = new Position(intersectionI.getIntersectionPosition().getLatitude(), intersectionI.getIntersectionPosition().getLongitude(), intersectionI.getIntersectionPosition().getElevation()*factor);
				System.out.println("******: "+poscicle1);
				poslist.add(poscicle1);            	
			}
	
       	for(int f=0; f<poslist.size(); f++)
       		{   
       	 	System.out.println("&&& "+poslist.get(f));

       	 	//Position newpos = new Position(poslist.get(f).getLatitude(), poslist.get(f).getLongitude(), poslist.get(f).getElevation());
     	  
       	 	
       	 	iPoint2= new PointPlacemark(poslist.get(f));  
       	 	
       		}
       	
        	PointPlacemarkAttributes pointAttributesFill = new PointPlacemarkAttributes();                      
        	iPoint2.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
                    	
            
            /* 
        	//THIS IS A SIMPLE COLOR          
            if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=35)
            {
            	double factor=(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5))/255;           	
            	pointAttributes.setLineMaterial(Material.GREEN);
            }
            else if(intersection.getIntersectionPosition().getElevation()>35 && intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=50)
            {
            	double factor=(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5))/255;           	
            	pointAttributes.setLineMaterial(Material.CYAN);
            }
            else if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)>50)
            {
            	pointAttributes.setLineMaterial(Material.BLUE);           	
            }
            */
                    
	        // THIS IS A GRADIENT COLOR
	        //Color for gradient
	    	Color brown = new Color(210, 63, 50);
	    	Color gold = new Color(210, 100, 50);
	    	Color lightG = new Color(210, 137, 32);
	    	Color lightY = new Color(255, 230, 192);
	        	   
	        if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=35)
	        {
	            double factor1=(Math.abs(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)/50));
	            
	            pointAttributesFill.setLineMaterial( new Material(interpolateColor(lightG,lightY, factor1)));
	     
	        }
	        else if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/50)>35 && intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)<=50)
	        {
	            double factor2=(Math.abs(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5))/50);
	         
	            pointAttributesFill.setLineMaterial(new Material(interpolateColor (gold, lightY, factor2)));
	      
	        }
	        else if(intersection.getIntersectionPosition().getElevation()/(ShpLoader3D.vexa/5)>50)
	        {	          
	            pointAttributesFill.setLineMaterial(new Material (interpolateColor(brown, gold, 1)));	
	        	  
	        }	      	                   
            pointAttributesFill.setUsePointAsDefaultImage(true); 
            pointAttributesFill.setScale(8.0);
            iPoint2.setAttributes(pointAttributesFill);  
			return iPoint2;
        }
        
        
        protected Polygon drawPolygon(double latA, double lonA, double latB, double lonB, double latC, double lonC)
        {
            // Create the polygon boundary and then the polygon.
            List<Position> positionsPo = new ArrayList<Position>();
            positionsPo.add(Position.fromDegrees(latA, lonA, 0*ShpLoader3D.vexa/5));
            positionsPo.add(Position.fromDegrees(latB, lonB, 61*ShpLoader3D.vexa/5));
            positionsPo.add(Position.fromDegrees(latC, lonC, 45*ShpLoader3D.vexa/5));
            positionsPo.add(Position.fromDegrees(latA, lonA, 0*ShpLoader3D.vexa/5));

            this.polygon = new Polygon(positionsPo);
            this.polygon.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);

            // Set some of the shape's attributes
            ShapeAttributes attrs = new BasicShapeAttributes();
            attrs.setInteriorMaterial(Material.LIGHT_GRAY);
            attrs.setInteriorOpacity(0);
            this.polygon.setAttributes(attrs);
            return polygon;
        }
        
        //calculus and create the line of intesection       
        public RenderableLayer computeLineInterceptor(double latA, double lonA, double pointA, double latB, double lonB, double pointB, double latC, double lonC, double pointC,  ExtrudedPolygon extPoly, AppFrame appFrame, double factor) 
        {
      	
        	HashMap<Position, Object> positionInfo;	            		    		

			//put latitude and longitude in array
			double[] latArray = new double[3];
			latArray[0]=latA;
			latArray[1]=latB;
			latArray[2]=latC;
			
			double[] lonArray = new double[3];
			lonArray[0]=lonA;
			lonArray[1]=lonB;
			lonArray[2]=lonC;
			
			double[] pointArray = new double[3];
			pointArray[0]=pointA;
			pointArray[1]=pointB;
			pointArray[2]=pointC;

    		double latCornerA= maxLat(latArray);
    		double lonCornerA= minLon(latArray, lonArray);
    		double latCornerB= maxLat(latArray);
    		double lonCornerB= maxLon(latArray, lonArray);
    		double latCornerC= minLat(latArray);
    		double lonCornerC= maxLon(latArray, lonArray);
    		double latCornerD= minLat(latArray);
    		double lonCornerD= minLon(latArray, lonArray);

    		//DRAW GRID AND LINE INTERCEPTOR   				
            // Create the grid and its positions. This one is rectangular; it need not be, but must be four-sided.
            List<Position> corners = new ArrayList<Position>();
            corners.add(Position.fromDegrees(latCornerA, lonCornerA, 0));
            corners.add(Position.fromDegrees(latCornerB, lonCornerB, 0));
            corners.add(Position.fromDegrees(latCornerC, lonCornerC, 0));
            corners.add(Position.fromDegrees(latCornerD, lonCornerD, 0));
                            
            NUM_POINTS_WIDE2 = (int) ((lonCornerB-lonCornerA)*100000/gridsWIDE);
            NUM_POINTS_HIGH2 = (int) ((latCornerA-latCornerC)*100000/gridsHIGH);
        
            // Create a hash map to store the data associated with each position.
            positionInfo = new HashMap<Position, Object>(NUM_POINTS_WIDE2 * NUM_POINTS_HIGH2);

            // Populate the position list with positions and the positionInfo map with data.
            int aDataValue = 0;// generate an arbitrary data value
            
            PositionIterator posIter = new PositionIterator(corners, NUM_POINTS_WIDE2, NUM_POINTS_HIGH2);
     
            //create new rendable Line layer
            RenderableLayer line = new RenderableLayer();
           
            Path path = null;
            
            while (posIter.hasNext())
            {
                Position position = posIter.next();
                positions.add(position);           
//--------------------DRAW LINE OF INTERCEPTOR-------------------------------------------                                                  
                Position pB = new Position(position, (maxPointValue(pointArray)+1)*ShpLoader3D.vexa/5);
                path = new Path(position, pB);
                ShapeAttributes pathAttributes = new BasicShapeAttributes();
                path.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
                pathAttributes.setOutlineMaterial(Material.GREEN);
                pathAttributes.setOutlineOpacity(0.6);
                pathAttributes.setDrawOutline(true);
                pathAttributes.setDrawInterior(false);
                path.setAttributes(pathAttributes);    
  				line.addRenderable(path);
  				
  				getColorMap(position, extPoly, appFrame, factor);
  				line.addRenderable(path);
//--------------------DRAW LINE OF INTERCEPTOR-------------------------------------------                
                positionInfo.put(position, aDataValue++);                                          
            }          

            System.out.println("^^ " +positions.get(1));
            System.out.println("^^ " +positions.get(2));       
        	double dist= (double)Math.round((LatLon.ellipsoidalDistance(positions.get(2), positions.get(1), 6378100, 6356800))*100)/100;
        	xmeter=  ""+dist; 
        	System.out.println("^^_^^ " +xmeter);
        	ShpLoader3D.tgridres.setText("m: "+ xmeter +" - tot points: "+totalinterp);
            return line;                  
        }     
        
        public RenderableLayer computePointInterceptor(double latA, double lonA, double pointA, double latB, double lonB, double pointB, double latC, double lonC, double pointC,  ExtrudedPolygon extPoly, AppFrame appFrame, double factor) 
        {
        	HashMap<Position, Object> positionInfoPoint;

			//put latitude and longitude in array
			double[] latArray = new double[3];
			latArray[0]=latA;
			latArray[1]=latB;
			latArray[2]=latC;
			
			double[] lonArray = new double[3];
			lonArray[0]=lonA;
			lonArray[1]=lonB;
			lonArray[2]=lonC;
			
			double[] pointArray = new double[3];
			pointArray[0]=pointA;
			pointArray[1]=pointB;
			pointArray[2]=pointC;

    		double latCornerA= maxLat(latArray);
    		double lonCornerA= minLon(latArray, lonArray);
    		double latCornerB= maxLat(latArray);
    		double lonCornerB= maxLon(latArray, lonArray);
    		double latCornerC= minLat(latArray);
    		double lonCornerC= maxLon(latArray, lonArray);
    		double latCornerD= minLat(latArray);
    		double lonCornerD= minLon(latArray, lonArray);
    		
    		//DRAW GRID AND LINE INTERCEPTOR   				
            // Create the grid and its positions. This one is rectangular; it need not be, but must be four-sided.
            List<Position> corners = new ArrayList<Position>();
            corners.add(Position.fromDegrees(latCornerA, lonCornerA, 0));
            corners.add(Position.fromDegrees(latCornerB, lonCornerB, 0));
            corners.add(Position.fromDegrees(latCornerC, lonCornerC, 0));
            corners.add(Position.fromDegrees(latCornerD, lonCornerD, 0));
           
            // Create a hash map to store the data associated with each position.
            positionInfoPoint = new HashMap<Position, Object>(NUM_POINTS_WIDE2 * NUM_POINTS_HIGH2);

            // Populate the position list with positions and the positionInfo map with data.
            int aDataValue = 0;// generate an arbitrary data value
            PositionIterator posIter = new PositionIterator(corners, NUM_POINTS_WIDE2, NUM_POINTS_HIGH2);
           
            RenderableLayer pointlayer = new RenderableLayer();

            List<Position> positions = new ArrayList<Position>(NUM_POINTS_WIDE2 * NUM_POINTS_WIDE2);
            
            while (posIter.hasNext())
            {
                Position position = posIter.next();
                positions.add(position);
             
//--------------------DRAW POINTS OF INTERCEPTOR-------------------------------------------                                                    				 				
                try {
                pointlayer.addRenderable(getColorMap(position, extPoly, appFrame, factor));
                pointlayer.addRenderable(getColorMapFill(position, extPoly, appFrame, factor));
                }
                catch(Exception exc)
                {
                	JOptionPane.showMessageDialog(null, "layer is null, use lower factor");
                	System.out.println(exc + "layer is null");
                	break;
                }
              
                positionInfoPoint.put(position, aDataValue++);                                          
            }
            
            //count how  are the interpolated value
             return pointlayer; 
        }            
    
    //find latitude min
    public double minLat(double[] latArray)
    {        	
    	double minlat=90;
    	for(int i=0;i<latArray.length; i++)
    	{
    		if(latArray[i]<=minlat){minlat=latArray[i];}
    	}
    	return minlat;
    }
    
    //find latitude max
    public double maxLat(double[] latArray)
    {
        double maxlat=0;
        for(int i=0;i<latArray.length; i++)
        {
        	if(Math.abs(latArray[i])>=maxlat){maxlat=latArray[i];}
        }
        return maxlat;
    }
    
    //find longitude min
    public double minLon(double[] latArray, double lonArray[])
    { 
        double minlon=360;
        for(int i=0;i<latArray.length; i++)
        {
        	if(Math.abs(lonArray[i])<=minlon){minlon=lonArray[i];}
        }
        return minlon;
    }
    
    //find longitude max
    public double maxLon(double[] latArray, double lonArray[])
    {
    	double maxlon=0;
    	for(int i=0;i<latArray.length; i++)
        {
        	if(lonArray[i]>=maxlon){maxlon=lonArray[i];}
        }
    	return maxlon;
    }
    
    //find max high point value
    public double maxPointValue(double[] pointArray)
    {
        //find longitude max
        double maxpoint=0;
        for(int i=0;i<pointArray.length; i++)
        {
        	if(pointArray[i]>=maxpoint){maxpoint=pointArray[i];}
        }
        return maxpoint;
    }
    
    public void insertPoint(double latA, double lonA, double pointA, double latB, double lonB, double pointB, double latC, double lonC, double pointC,  ExtrudedPolygon extPoly, AppFrame appFrame, double factor) 
    {	   	
    	String name="Points"+indexLayerPoint;
    	RenderableLayer layerPoint = computePointInterceptor( latA,  lonA, pointA,  latB, lonB,  pointB,  latC,  lonC,  pointC,   extPoly,  appFrame, factor);    	 
    	layerPoint.setName(name);
/*VIS*/ layerPoint.setEnabled(true);
        insertBeforeCompass(appFrame.getWwd(), layerPoint);
        indexLayerPoint++;
    }
    
    public void insertPointFill(double latA, double lonA, double pointA, double latB, double lonB, double pointB, double latC, double lonC, double pointC,  ExtrudedPolygon extPoly, AppFrame appFrame, double factor) 
    {	   	
    	String name="Fill"+(indexLayerPoint-1);
    	RenderableLayer layerPoint = computePointInterceptor( latA,  lonA, pointA,  latB, lonB,  pointB,  latC,  lonC,  pointC,   extPoly,  appFrame, factor);    	  	
    	layerPoint.setName(name);
/*VIS*/ layerPoint.setEnabled(true);
        insertBeforeCompass(appFrame.getWwd(), layerPoint);       
    }
    
    public void insertGrid(List<Position> corners, AppFrame appFrame)
    {            
    	gov.nasa.worldwindx.examples.lineofsight.PointGrid grid = new gov.nasa.worldwindx.examples.lineofsight.PointGrid(corners, positions, NUM_POINTS_WIDE2 * NUM_POINTS_HIGH2);  	
    	RenderableLayer layerGrid = new RenderableLayer();
    	layerGrid.addRenderable(grid); 
    	String name="Grid"+indexLayerPoint;
    	layerGrid.setName(name);
/*VIS*/	layerGrid.setEnabled(false);           
		insertBeforeCompass(appFrame.getWwd(), layerGrid);
    }
    
    public void insertLine(double latA, double lonA, double pointA, double latB, double lonB, double pointB, double latC, double lonC, double pointC,  ExtrudedPolygon extPoly, AppFrame appFrame, double factor) 
    {   	
    	RenderableLayer line = computeLineInterceptor( latA,  lonA, pointA,  latB, lonB,  pointB,  latC,  lonC,  pointC,   extPoly,  appFrame, factor);     	
    	String name="Interceptor Line"+indexLayerPoint;
    	line.setName(name);
/*VIS*/ line.setEnabled(false);
        insertBeforeCompass(appFrame.getWwd(), line);
    }
    
    public void insertPolygon(double latA, double lonA, double latB, double lonB, double latC, double lonC, AppFrame appFrame)
    {
        drawPolygon(latA, lonA,  latB,  lonB, latC,  lonC);

        // Add the shape to the display layer.
        this.layer = new RenderableLayer();
        this.layer.setName("Polygon");
        this.layer.addRenderable(this.polygon);
        insertBeforeCompass(appFrame.getWwd(), this.layer);	
    }
    
    public void insertPlaceMark(double latA, double lonA, double latB, double lonB, double latC, double lonC, AppFrame appFrame)
    {
		PointPlacemark pm1 = new PointPlacemark((Position.fromDegrees(latA, lonA)));	
		PointPlacemarkAttributes pointAttribute1 = new PointPlacemarkAttributes();				
		pm1.setAttributes(pointAttribute1);	
		pointAttribute1.setImageColor(Color.red);
		pm1.setVisible(true);
		
		PointPlacemark pm2 = new PointPlacemark((Position.fromDegrees(latB, lonB)));
		PointPlacemarkAttributes pointAttribute2 = new PointPlacemarkAttributes();				
		pm2.setAttributes(pointAttribute2);	
		pointAttribute2.setImageColor(Color.red);
		pm2.setVisible(true);
		
		PointPlacemark pm3 = new PointPlacemark((Position.fromDegrees(latC, lonC)));		
		PointPlacemarkAttributes pointAttribute3 = new PointPlacemarkAttributes();				
		pm3.setAttributes(pointAttribute3);			
		pointAttribute3.setImageColor(Color.red);
		pm3.setVisible(true);
		
		PointPlacemark pm4 = new PointPlacemark((Position.fromDegrees((latA+latB+latC)/3, (lonA+lonB+lonC)/3)));		
		PointPlacemarkAttributes pointAttribute4 = new PointPlacemarkAttributes();				
		pm4.setAttributes(pointAttribute4);			
		pointAttribute4.setImageColor(Color.blue);
		pm4.setVisible(true);
		
		RenderableLayer layer2 = new RenderableLayer();
		layer2.addRenderable(pm1);
		layer2.addRenderable(pm2);
		layer2.addRenderable(pm3);
		layer2.addRenderable(pm4);
		layer2.setName("placemark");
		insertBeforeCompass(appFrame.getWwd(), layer2);
    }
    
    /** Generates positions forming a lat/lon grid. */
    protected static class PositionIterator implements Iterator<Position>
    {
        protected int numWide = NUM_POINTS_WIDE2;
        protected int numHigh = NUM_POINTS_HIGH2;
        protected int w;
        protected int h;

        protected List<Position> corners;
        protected Position sw;
        protected Position se;
        protected Position ne;
        protected Position nw;

        public PositionIterator(List<Position> corners, int numPointsWide, int numPointsHigh)
        {
            this.corners = corners;
            this.sw = corners.get(0);
            this.se = corners.get(1);
            this.ne = corners.get(2);
            this.nw = corners.get(3);

            this.numWide = numPointsWide;
            this.numHigh = numPointsHigh;
        }

        public boolean hasNext()
        {
            return this.h < this.numHigh;
        }

        public Position next()
        {
            if (this.h >= this.numHigh)
                throw new NoSuchElementException("PointGridIterator");

            return this.computeNextPosition();
        }
        

        public void remove()
        {
            throw new UnsupportedOperationException("PointGridIterator");
        }

        protected Position computeNextPosition()
        {
            Position left, right;

            if (h == 0)
            {
                left = sw;
                right = se;
            }
            else if (h == numHigh - 1)
            {
                left = nw;
                right = ne;
            }
            else
            {
                double t = h / (double) (numHigh - 1);

                left = Position.interpolate(t, sw, nw);
                right = Position.interpolate(t, se, ne);
            }

            Position pos;

            if (w == 0)
            {
                pos = left;
                ++w;
            }
            else if (w == numWide - 1)
            {
                pos = right;

                w = ++h < numHigh ? 0 : w + 1;
            }
            else
            {
                double s = w / (double) (numWide - 1);
                pos = Position.interpolate(s, left, right);
                ++w;
            }
   
            return pos; 
        }
    }
    


    public static void main(String[] args)
    {
        // Configure the initial view parameters so that the balloons are immediately visible.
        Configuration.setValue(AVKey.INITIAL_LATITUDE, 43.8);
        Configuration.setValue(AVKey.INITIAL_LONGITUDE, 11.23142687);
        Configuration.setValue(AVKey.INITIAL_ALTITUDE, 10e3);
        Configuration.setValue(AVKey.INITIAL_HEADING, 27);
        Configuration.setValue(AVKey.INITIAL_PITCH, 30);

        ApplicationTemplate.start("World Wind Point Grid", AppFrame.class);
           
    }
}


