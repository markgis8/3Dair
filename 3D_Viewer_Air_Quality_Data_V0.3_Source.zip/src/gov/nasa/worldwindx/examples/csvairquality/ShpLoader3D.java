package gov.nasa.worldwindx.examples.csvairquality;

import gov.nasa.worldwind.Configuration;
import gov.nasa.worldwindx.examples.ApplicationTemplate;
import gov.nasa.worldwindx.examples.csvairquality.CsvEmReader;
import gov.nasa.worldwindx.examples.csvairquality.CsvLayer;
import gov.nasa.worldwindx.examples.csvairquality.ShpLayer;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.terrain.HighResolutionTerrain;
import gov.nasa.worldwind.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.Timer;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.*;
import java.io.IOException;
import java.util.*;
import java.util.List;


/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * Creates  a graphic interface to drag and drop and upload shape file and csv file.
 * You can specify the height column for shapefile's extrusion.
 * The csv file have a navigation panel. It contains the button to navigate forward and back trough the days, a automatic play, vertical scale control and limit layer control. 
 * 
 * @author Marco Piragnolo Cirgeo, University of Padua, marco.piragnolo@unipd.it
 * @version 0.3 PointInterpolator 2014-22-01 15:28
 */
/**Manages csv or shapefile upload*/

public class ShpLoader3D extends ApplicationTemplate {
	// Create text area with 3 rows and 3 columns for drag and drop
	static JTextArea ta = new JTextArea(2, 1);
	// Create text area with 3 rows and 3 columns for drag and drop
	static JTextArea tp = new JTextArea(2, 1);	
	// Create text area with 1 rows and 1 columns for write the name of column
	// height in dbf
	static JTextArea tv = new JTextArea(1, 1);
	
	static JTextArea tpd = new JTextArea(1, 1);
	// Text field for grid size
	static JTextArea tgrid = new JTextArea(1, 1);
	// Text for the result of calculus
	static JTextArea tgridres = new JTextArea(1, 1);
	
	// Create drop target
	static DropTarget dt;
	static DropTarget dt2;
	// Create the button to submit the shapefile
	static JButton b = new JButton("Click to upload");
	// Create the button to submit the csv
	static JButton b2 = new JButton("Click to upload");
	// Create the button to change grid
	static JButton b3 = new JButton("Change grid size");
	// Variables declaration
	int not = 0;
	static int check;
	static String path; //path of get correct shapefile url
	static String path2; //path to get correct csv url
	static String url = ""; //url of shape layer
	static String url2 = ""; //url of csv layer
	static String colheight = "";
	static String context=""; //variable for drag and drop shape file of csv
	static int day=1; //day index of play, forward, previous button
	static int update=0;
	static  Timer rtps;   //timer to auto play 
	static JSlider vertical; //Slider for vertical exaggeration
	static JSlider gridsize; //Slider for vertical exaggeration
	static int delay = 2500; //milliseconds play stop
	static int rr=0; //start and stop index button
	static int vexa=0; //Factor height for csv layer with controlled by JSlider
	static boolean limitlay=false; //active or disable the limit layer
	static int ll=0; //limit index button
	static int inuplayer=0; //index to upload point layer
	/**Creates the panel to upload and manage csv or shapefile*/
	public static class AppFrame extends ApplicationTemplate.AppFrame implements DropTargetListener {
		protected static HighResolutionTerrain terrain;
		private static final long serialVersionUID = 1L;
		protected List<Layer> layers = new ArrayList<Layer>();	

		
		/**Creates control Panel
		 * @return */
		protected JPanel makeControlPanel() {
			JButton prev =  new JButton("<<");
			JButton play = new JButton("play/stop" );
			JButton next = new JButton(">>");
			JButton limit = new JButton("limit");
			JPanel panel = new JPanel();
			JPanel panel2 = new JPanel();
			
			panel.setLayout(new BoxLayout(panel,  BoxLayout.PAGE_AXIS)); 	
			panel.setBorder(new CompoundBorder(BorderFactory.createEmptyBorder(
					4, 4, 4, 4), new TitledBorder("")));
			panel.setAlignmentX(LEFT_ALIGNMENT);
			
			panel2.setLayout(new FlowLayout(FlowLayout.LEADING));
			panel2.setBorder(new CompoundBorder(BorderFactory.createEmptyBorder(
					4, 4, 4, 4), new TitledBorder("DAYS NAVIGATOR")));
			panel2.setAlignmentX(LEFT_ALIGNMENT);
			
			
		
			// Add text area for drag and drop shapefile to the panel 
			// JText area for shapefile 
			ta.setBackground(Color.white);
			ta.setEnabled(true);// JTextArea is enable
			ta.setToolTipText("Drag here your shapefile");
			ta.setAlignmentX(LEFT_ALIGNMENT);
			ta.setName("shapetarget");
			ta.setLineWrap(isEnabled());
			// JText area for height column
			tv.setToolTipText("Write the name of column height in dbf. Default column is UN_VOL_AV");
			tv.setAlignmentX(LEFT_ALIGNMENT);			
			
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			panel.add(new JLabel("Drag your shapefile"));
			panel.add(ta);
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			panel.add(new JLabel(
					"<html><body>Default height column is UN_VOL_AV. <br>If you don't use it, specify the column name</body></html>"));
			// Add text area for height column name to the panel
			panel.add(tv);
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			// Add upload shape button to the panel
			panel.add(b);
			
			// Add text area for drag and drop csv to the panel	
			// JText area for csv
			tp.setBackground(Color.white);
			tp.setEnabled(true);// JTextArea is enable
			tp.setToolTipText("Drag here your csv");
			tp.setAlignmentX(LEFT_ALIGNMENT);
			tp.setName("csvtarget");
			tp.setLineWrap(isEnabled());
			
	
			// Set grid size	
			tgrid.setBackground(Color.white);
			tgrid.setEnabled(true);// JTextArea is enable
			tgrid.setToolTipText("Set grid size");
			tgrid.setAlignmentX(LEFT_ALIGNMENT);
			tgrid.setName("gridsize");
			tgrid.setLineWrap(isEnabled());
			tgrid.setToolTipText("Insert grid low values to have more precision(slow) and high value for low precsion(fast)");			
			
			tgridres.setBackground(Color.white);			
			tgridres.setEnabled(true);// JTextArea is enable
			tgridres.setEditable(false);
			tgridres.setToolTipText("meters");
			tgridres.setAlignmentX(LEFT_ALIGNMENT);
			tgridres.setName("gridmeter");
			tgridres.setLineWrap(isEnabled());
			tgridres.setToolTipText("Meters of the grid");
			
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			panel.add(new JLabel("Drag your csv"));
			panel.add(tp);
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			//Add upload button to panel
			panel.add(b2);
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			//Add vertical label		
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			panel.add(new JLabel("Vertical scale"));
			
			//Shape file upload button
			b.addActionListener(new ActionListener() 
			{ // implements the action listener interface
				public void actionPerformed(ActionEvent e) { 
					// implements action performed method get the name of the specify the height name column
					colheight = tv.getText();
					url = getPath();
					// invoke the method the load the new Shapefile layer
					update=0;
					dropOpenShpButton();
					// clear the field for specify the height name column
					tv.setText(null);
				}
			});
			
			
			//Csv upload button
			b2.addActionListener(new ActionListener()
			{ // implements the action listener interface
				public void actionPerformed(ActionEvent e) { 
					url2 = getPath2();
					update=0;
					// invoke the method the load the new Shapefile layer
					dropOpenCsvButton();
				}
			});
			
			//Slider
			vertical = new JSlider();
			vertical.setPaintLabels(true);
			vertical.setPaintTicks(true);
			vertical.setMinorTickSpacing(5);
			vertical.setMajorTickSpacing(20);
			vertical.setValue(50);
			vertical.addMouseMotionListener(new MouseMotionAdapter() {				
			});
			vertical.setAlignmentX(LEFT_ALIGNMENT);
			panel.add(vertical);			
			vexa=vertical.getValue();
			vertical.addChangeListener(new ChangeListener(){
				@Override
				public void stateChanged(ChangeEvent e) {
					// TODO Auto-generated method stub
					JSlider vertical = (JSlider)e.getSource();
					//checks whether a specific event (a change) is part of a chain and return true; false if it's final one
					if (!vertical.getValueIsAdjusting()){
						vexa=vertical.getValue();									
						{
							url2 = getPath2();
							if (url2.isEmpty())
							{JOptionPane.showMessageDialog(null, "Need to upload csv file");
							}
							else
							{						
							// invoke the method the update the new csv layer
							update=1;
							dropCsvUpdateButton();
							}
						}
					}
				}
			});

			
			b3.addActionListener(new ActionListener()
			{ // implements the action listener interface
				public void actionPerformed(ActionEvent e) {					
					PointInterpolator.gridsWIDE=Integer.parseInt(tgrid.getText());
					PointInterpolator.gridsHIGH=Integer.parseInt(tgrid.getText());
					// invoke the method the load the new Shapefile layer
					update=1;
					dropOpenCsvButton();
					if(PointInterpolator.totalintepolation!=0){PointInterpolator.totalintepolation=0;}
					if(tgridres.getText()!=""){				 
					   tgridres.setText(PointInterpolator.xmeter + " "+PointInterpolator.totalinterp);}
					else{
						//tgridres.setText(pointInterpolator2.xmeter);
						tgridres.setText(null);
						}
				}
			});
			
			panel.add(new JLabel(" "));
			panel.add(new JLabel("Set precision's value; default is 50"));
			panel.add(new JLabel("Low=more precise (slow), high=less precise (fast)"));
			panel.add(tgrid);	
			panel.add(new JLabel("meters"));
			panel.add(tgridres);
			panel.add(b3);
			
			
			//Previous button <<
			prev.addMouseListener(new MouseAdapter() 
			{
				@Override
				public void mouseClicked(MouseEvent e) 
				{
					url2 = getPath2();
					if (url2.isEmpty())
					{JOptionPane.showMessageDialog(null, "Need to upload csv file");
					}
					else
					{
					CsvEmReader em = new CsvEmReader();	
					day--;
						try {
							if(day<1){day=em.getNumberDay();}
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}					
						// invoke the method the update the new csv layer
						update=1;
						dropCsvUpdateButton();
						}
					}
			});	
			
			prev.setFont(new Font("Trebuchet MS", Font.PLAIN, 10));
			
			prev.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});		
			panel2.add(prev);
			
			
			//Play stop button
			play.addMouseListener(new MouseAdapter() 
				{
					@Override
					public void mouseClicked(MouseEvent e) 
					{
						rr++;
						 if((rr & 1)==1){ rtps.start();}
						 else if ((rr & 1)==0) {rtps.stop();};
					}
				});				
			play.setFont(new Font("Trebuchet MS", Font.PLAIN, 10));
			panel2.add(play);	
			 
			  ActionListener taskP = new ActionListener() 
			  {    
			      public void actionPerformed(ActionEvent evt) 
			      {	  		
						url2 = getPath2();
						if (url2.isEmpty())
						{JOptionPane.showMessageDialog(null, "Need to upload csv file");
						rtps.stop();}
						else
						{
				    	  CsvEmReader em = new CsvEmReader();	
				    	  	day++;	
							try {
								if(day>em.getNumberDay()){day=1;}
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							// invoke the method the update csv layer
							update=1;
							dropCsvUpdateButton(); 
						}
			      } 
			  };
			 
			//timer
		  	rtps = new Timer( delay , taskP);
   				
			//Next button >>
			next.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) 
				{
					url2 = getPath2();			
					if (url2.isEmpty())
					{JOptionPane.showMessageDialog(null, "Need to upload csv file");
					}
					else
					{
					CsvEmReader em = new CsvEmReader();	
					day++;
						try {
							if(day>em.getNumberDay()){day=1;}
						} catch (IOException e1) {
							e1.printStackTrace();
						}								
					// invoke the method the load the new Shapefile layer
					update=1;
					dropCsvUpdateButton();
					}
				}
			});		
			next.setFont(new Font("Trebuchet MS", Font.PLAIN, 10));	
			panel2.add(next);
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			

			//Limit button
			limit.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) 
				{
					url2 = getPath2();
					if (url2.isEmpty())
					{JOptionPane.showMessageDialog(null, "Need to upload csv file");
					}
					else
					{
					ll++;
					 if((ll & 1)==1){ limitlay=true;}
					 else if ((ll & 1)==0) {limitlay=false;};											
					// invoke the method the load the new Shapefile layer
					update=1;
					dropCsvUpdateButton();				
					}
				}
			});		
			limit.setFont(new Font("Trebuchet MS", Font.PLAIN, 10));	
			panel2.add(limit);
			panel.add(Box.createRigidArea(new Dimension(0, 8)));
			
			
			//Add button panel to main panel
			panel.add(panel2);
						
			//Drop target
			dt = new DropTarget(ta, this);
			dt2 = new DropTarget(tp, this); 
			this.getLayerPanel().add(panel, BorderLayout.SOUTH);
			return panel;
		}

		public AppFrame() {
			// Add our control panel.
			// Add control panel line  to a frame separate from the world window.
            JFrame controlFrame = new JFrame();
            controlFrame.getContentPane().add(makeControlPanel());
            controlFrame.pack();
            controlFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            controlFrame.setVisible(true);  
		}


		/**Get the correct format of the shapefile path*/
		public String getPath() {
			path = ta.getText(); // assign the text value to class variable "path"
			return path.replace("\\", "/").replaceAll("\n", "");
		}
		
		/**Get the correct format of the csv path*/
		public String getPath2() {
			path2 = tp.getText(); // assign the text value to class variable "path"
			return path2.replace("\\", "/").replaceAll("\n", "");
		}

		/**When mouse enter the text in the panel is cancelled*/
		public void dragEnter(DropTargetDragEvent dtde) {
			ta.setText("");
			context = dtde.getDropTargetContext().getDropTarget().getComponent().getName();
			if (context=="csvtarget")
			{tp.setText("");}
			check = 0;
		}

		public void dragOver(DropTargetDragEvent dtde) {
		}

		public void dropActionChanged(DropTargetDragEvent dtde) {
		}

		
		public void drop(DropTargetDropEvent dtde) 
		{	
			//get the name of the text area
			context = dtde.getDropTargetContext().getDropTarget().getComponent().getName();
			if (context=="shapetarget"){
			try {
				Transferable tr = dtde.getTransferable();
				DataFlavor[] flavors = tr.getTransferDataFlavors();
				for (int i = 0; i < flavors.length; i++) {
					if (flavors[i].isFlavorJavaFileListType()) {
						// Accept drag and drop
						dtde.acceptDrop(DnDConstants.ACTION_COPY);
						java.util.List<?> list = (java.util.List<?>) tr
								.getTransferData(flavors[i]);
						for (int j = 0; j < list.size(); j++) {
							ta.append(list.get(j) + "\n");
							check = 1; // set check value
						}
						// Complete drag and drop
						dtde.dropComplete(true);					
						}
					}
					dtde.rejectDrop();
				} catch (Exception e) {
					e.printStackTrace();
					dtde.rejectDrop();
				}
			}
			else if (context=="csvtarget"){
			try {
				Transferable tr = dtde.getTransferable();
				DataFlavor[] flavors = tr.getTransferDataFlavors();
				for (int i = 0; i < flavors.length; i++) {
					if (flavors[i].isFlavorJavaFileListType()) {
						// Accept drag and drop
						dtde.acceptDrop(DnDConstants.ACTION_COPY);
						java.util.List<?> list = (java.util.List<?>) tr
								.getTransferData(flavors[i]);
						for (int j = 0; j < list.size(); j++) {
							tp.append(list.get(j) + "\n");
							check = 1; // set check value
						}
						// Complete drag and drop
						dtde.dropComplete(true);				
						}
					}
					dtde.rejectDrop();
				} catch (Exception e) {
					e.printStackTrace();
					dtde.rejectDrop();
				}
			}
		}

		public void dragExit(DropTargetEvent dte) {
		}

		/**When open a sahpefile starts a new thread*/
		public void dropOpenShpButton() {
			Thread t = new WorkerThread(url, this);
			t.start();
			((Component) getWwd()).setCursor(new Cursor(Cursor.WAIT_CURSOR));
		}
		
		/**When open a csv starts a new thread*/
		public void dropOpenCsvButton() {
			Thread t= new WorkerThread(url2, this);
			t.start();
			((Component) getWwd()).setCursor(new Cursor(Cursor.WAIT_CURSOR));
		}
		
		/**When update a csv starts a new thread*/
		public void dropCsvUpdateButton() {
			Thread t= new WorkerThread(update, this);
			t.start();
			((Component) getWwd()).setCursor(new Cursor(Cursor.WAIT_CURSOR));
		}

	}

	/**This class creates a new thread to upload, update csv or shapefile*/
	public static class WorkerThread extends Thread {
		protected Object source;
		protected static AppFrame appFrame;
		protected String colname;
		protected String file;
		//index to count every shapefile upoload 
		static int shpindex=0;
		//insert to count every csv upload
		static int csvindex=0;
		String delname="";
		private HighResolutionTerrain terrain;
				
		public WorkerThread(Object source, AppFrame appFrame) {
			this.source = source;
			this.appFrame = appFrame;
			this.colname = colheight;
			this.file = context;
		}
		
		public static HighResolutionTerrain getTerrain()
		{
			
			HighResolutionTerrain terrain2=new HighResolutionTerrain(WorkerThread.appFrame.getWwd().getModel().getGlobe(), 20d);
		return terrain2;
		}

		public static AppFrame getAppFrame()
		{
			AppFrame appframe=WorkerThread.appFrame;
			return appframe;			
		}

		public void run() {
			//When a new shapefile is dragged and we try to navigate the context is set as csv file
			if (file=="shapetarget" && update==1){ context="csvtarget"; update=1; file="csvtarget";}
			if (file=="shapetarget" && update==0){
				try {	
						final List<Layer> layers = this.makeShapefileLayers();
						for (int i = 0; i < layers.size(); i++) {
							String name = this.makeDisplayName(this.source);
							layers.get(i).setName(
									i == 0 ? name : name + "-" + Integer.toString(i));	
						}				
	
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								for (Layer layer : layers) {
									insertBeforeLayerName(appFrame.getWwd(), layer, "Open Street Map");
									shpindex++;
								}
		
								appFrame.getLayerPanel().update(appFrame.getWwd());
										
								ShpLayer viewcoord = new ShpLayer();
								// Calculate the angle of field of view
								Angle beta = appFrame.getWwd().getView()
										.getFieldOfView();
								// Calculate the height of field of view
								double height = (viewcoord.getShpBase(source)/2)
										/ (beta.divide(2)).sin();
		
								appFrame.getWwd()
										.getView()
										.setEyePosition(
												Position.fromDegrees(
														viewcoord.getCentreLat(source),
														viewcoord.getCentreLon(source),
														height));
							}				
						});
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								((Component) appFrame.getWwd()).setCursor(Cursor
										.getDefaultCursor());
							}
					});
				}
			}
			
			// if the file is csv upgrade the panel		
			else if (file=="csvtarget"  && update==0){
				try {	
					final List<Layer> layerscsv = this.makeCsvfileLayers();
					for (int i = 0; i < layerscsv.size(); i++) {
						//String name = this.makeDisplayName(this.source);						
						//int	day = dd.getCurrentDay();
						CsvEmReader dn = new CsvEmReader();
						String dname[] = dn.getDateName();
						day=1;
						String name = dname[(day*dn.getNumberPoint())-1];					
						layerscsv.get(i).setName(i == 0 ? name : name + "-" + Integer.toString(i));
						delname=layerscsv.get(i).getName();		
					 }				

					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							//for each
							for (Layer layer : layerscsv) {

								//appFrame.getWwd().addSelectListener(new BasicDragger(appFrame.getWwd()));
								layer.setName(delname);
								appFrame.getWwd().getModel().getLayers().toString();
								
								insertBeforePlacenames(appFrame.getWwd(), layer);
								
								csvindex++;						
							}
														
							
							appFrame.getLayerPanel().update(appFrame.getWwd());	
													
							CsvLayer viewcoord = new CsvLayer();
							// Calculate the angle of field of view
							Angle beta = appFrame.getWwd().getView()
									.getFieldOfView();
							// Calculate the height of field of view
							double height = 0;
							try {
								height = (viewcoord.getCsVBase() / 2)
										/ (beta.divide(2)).sin();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
	
							try {
								appFrame.getWwd()
										.getView()
										.setEyePosition(
												Position.fromDegrees(
														viewcoord.getCsvCentreLat(),
														viewcoord.getCsvCentreLon(),
														height));
							} catch (IOException e) {
							e.printStackTrace();
							}
						}				
					});
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							((Component) appFrame.getWwd()).setCursor(Cursor
									.getDefaultCursor());
						}
					});
				}
			}
			else if (file=="csvtarget" && update==1)
			{
				try {	
					CsvEmReader dn = new CsvEmReader();
					String dname[] = dn.getDateName();
					String dayname = dname[(day*dn.getNumberPoint())-1];
				
					final List<Layer> layers = this.clearCsvfileLayers();					 
					
					for (int i = 0; i < layers.size(); i++) {
						layers.get(i).setName(
								i == 0 ? dayname : dayname + "-" + Integer.toString(i));	
					}				
	
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {	
							for (Layer layer : layers) {				
								insertBeforePlacenames(appFrame.getWwd(), layer);	
								appFrame.layers.add(layer);
							}
							appFrame.getLayerPanel().update(appFrame.getWwd());
		
						}				
					});
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								((Component) appFrame.getWwd()).setCursor(Cursor
										.getDefaultCursor());
							}
						});
				}			
			}//end if else		
		}//end run
		
		/**This method creates a List Layer from a shapefile*/
		protected List<Layer> makeShapefileLayers() {
				ShpLayer loader = new ShpLayer();
				return (List<Layer>) loader.shpLayer(this.source, colname);			
		}
		
		/**This method creates a List Layer from a csv*/
		protected List<Layer> makeCsvfileLayers() throws IOException {
				CsvLayer loader2 = new CsvLayer();
				return (List<Layer>) loader2.csvLayer(this.source, day, vexa, limitlay);			
		}

		/**This method creates the string name of shapefile*/
		protected String makeDisplayName(Object source) {
			String name = WWIO.getSourcePath(source);
			if (name != null)
				name = WWIO.getFilename(name);
			if (name == null)
				name = "Shapefile";
			return name;
		}
		
		/**This method clears the layer created from csv and replaces with a new layer */
		protected List<Layer> clearCsvfileLayers() throws IOException{			
			int positiondelete=shpindex+csvindex+14;			
			//System.out.println(appFrame.getWwd().getModel().getLayers().get(14) +" "+positiondelete);	
			appFrame.getWwd().getModel().getLayers().remove(positiondelete);			
			
			while(inuplayer<PointInterpolator.indexLayerPoint)
			{				
				System.out.println("�_�_�_� NULL IN / INDEX" +inuplayer + " / "+PointInterpolator.indexLayerPoint);
				appFrame.getWwd().getModel().getLayers().remove(appFrame.getWwd().getModel().getLayers().getLayerByName("Grid"+inuplayer));
				appFrame.getWwd().getModel().getLayers().remove(appFrame.getWwd().getModel().getLayers().getLayerByName("Interceptor Line"+inuplayer));
				appFrame.getWwd().getModel().getLayers().remove(appFrame.getWwd().getModel().getLayers().getLayerByName("Points"+inuplayer));											
				appFrame.getWwd().getModel().getLayers().remove(appFrame.getWwd().getModel().getLayers().getLayerByName("Fill"+inuplayer));
				inuplayer++;
				System.out.println("�_�_�_� IN / INDEX" +inuplayer + " / "+PointInterpolator.indexLayerPoint);
			}
			
			//pointInterpolator2.indexLayerPoint=0;
			appFrame.getWwd().getModel().getLayers().remove("Grid");
			appFrame.getWwd().getModel().getLayers().remove("Interceptor Line");
			CsvLayer loader2 = new CsvLayer();
			return (List<Layer>) loader2.csvLayer(this.source, day, vexa, limitlay);
		}		
	}


	
	public static void main(String[] args) {
		Configuration.setValue(AVKey.INITIAL_LATITUDE, 43.4386);
		Configuration.setValue(AVKey.INITIAL_LONGITUDE, 11.7786);
		Configuration.setValue(AVKey.INITIAL_ALTITUDE, 25e5);
		start("World Wind ShapLoader3D", AppFrame.class);
	}
}
