package gov.nasa.worldwindx.examples.csvairquality;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * This class reads the csv file. The structure of csv file is: 
 * The first line of csv must be void. 
 * The second line declare the number of point. 
 * The third line declare the number of days.
 * The fourth line declare number and point's name.
 * In the next lines declare the x , y coordinates and date, z value.
 * @author Marco Piragnolo Cirgeo, University of Padua, marco.piragnolo@unipd.it
 * @version 0.1 CsvEmReader 2013-21-05 12:34
 */

/**Read all csv document*/
public class CsvEmReader {

	/**read all the document*/
	public String readDoc(String string) 
	{	 BufferedReader br;
	    String text = "";
	    int read, N = 1024 * 1024;
	    char[] buffer = new char[N];

	    try {
	        FileReader fr = new FileReader(string);
	        br = new BufferedReader(fr);
	        while(true) {
	            read = br.read(buffer, 0, N);
	            text += new String(buffer, 0, read);

	            if(read < N) {
	                break;      
	            }
            br.close();      
	        }
	    } catch(Exception ex) {
	        ex.printStackTrace();
	    }	  
	    
	    return text;	    	    
	}

	
	public String readLine() throws IOException 
	{
		   BufferedReader brl = new BufferedReader(new FileReader(ShpLoader3D.url2));		   
		   try 
		   {
		        StringBuilder sb = new StringBuilder();
		        String line = brl.readLine();		
		        while (line != null) {
		            sb.append(line);
		            sb.append("\n");
		            line = brl.readLine();
		        }
		   } 
		   catch(Exception ex) {
		        ex.printStackTrace();
		   }
		   finally 
		   {
			   brl.close();
		   }
		return null;
	}
	
	/** extract the number of point declared in the csv and returns a int*/
	public int getNumberPoint() throws IOException
	{	
		//declare number of the line
		int nline = 0;
		//Declare number of point
		int numberpoint = 0;
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {	
		        //create string line
		        String line = br.readLine();
		
		        while (line != null) 
		        {	
		            line = br.readLine();
		        	nline++;
		        	//read until 1 line
		        	if(nline==1)
		        	{
		        	//Split the string to obtain an array with two values
		        	String npoint[] = line.split(",");
		        	// convert the string to int 
		            numberpoint = Integer.parseInt(npoint[1]);		           
		            }		        	 
		        }
		   } 
		   finally 
		   {
			   br.close();
		   } 
		return numberpoint;
	}
	
	/** extract the number of days declared in the csv and returns a int */
	public int getNumberDay() throws IOException
	{	
		//Declare number of the line
		int nline = 0;
		//Declare number of days
		int numberday = 0;
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		       
			   	//create string line
		        String line = br.readLine();
		
		        while (line != null) {		         
		            line = br.readLine();
		        	nline++;
		        	//read until 2 line
		        	if(nline==2)
		        	{	        	
		        	String npoint[] = line.split(",");
		        	// convert the string to int 
		            numberday = Integer.parseInt(npoint[1]);
		            }
		        	 
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }  
		return numberday;
	}
	
	
	/** Extract the name of the point declared in the csv returns an array object */
	public String[] getNamePoint() throws IOException 
	{	
		//array declaration
		String[] pointname = null;
		//The element of the array pointname are obtained with the method getNumberPoint
		pointname = new String[getNumberPoint()];	
		//string used in the array construction
		String pname = "";
		//Number line index
		int nline = 0;
		//Array index
		int i = 0;
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		   
		        String line = br.readLine();
		       
		        while (line != null) {	

		            line = br.readLine();
		        	nline++;
		        	//The line are between 4 and 4+number point in the csv file
		        	if(nline>=4 & nline < 4+getNumberPoint())
		        	{
		        	
		        	//Split the string to obtain an array with two values	
		        	String npoint[] = line.split(","); 		        	
		        	//remove the char ""
		        	pname = npoint[1].replace('"', ' '); 
		        	//remove the whitespace
		        	String pname2 = pname.replaceAll(" ", "");
		        	//conversion to string
		        	pname = pname2.toString();
		        	//assign to the element i of the array, the value of the current line in the variable pname
		        	pointname[i] = pname;
		        	//increment the index of array
		        	i++;
		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }
		return pointname;    	
     }
	
	
	/**Extract the name of all days for all points and row and returns an array object*/
	public String[] getDateName() throws IOException 
	{	
		//array declaration
		String[] pointdate = null;
		//The element of the array pointdate are obtained with the method getNumberPoint*getNumberDay
		pointdate = new String[getNumberPoint()*getNumberDay()];	
		//string used in the array construction
		String pdate = "";
		//Number line index
		int nline = 0;
		//Array index
		int i = 0;
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		   
		        String line = br.readLine();
		       
		        while (line != null) {	

		            line = br.readLine();
		        	nline++;
		        	//The line are between 4 and 4+number point in the csv file
		        	if( nline>=(6+(2*getNumberPoint())) & nline < (6+(2*getNumberPoint())+(getNumberPoint()*getNumberDay())) )
		        	{		        	
		        	//Split the string to obtain an array with two values	
		        	String npoint[] = line.split(","); 		        	
		        	//remove the char ""
		        	pdate = npoint[0].replace('"', ' '); 
		        	//remove the whitespace
		        	String pname2 = pdate.replaceAll(" ", "");
		        	//conversion to string
		        	pdate = pname2.toString();
		        	//assign to the element i of the array, the value of the current line in the variable pname
		        	pointdate[i] = pdate;
		        	//increment the index of array
		        	i++;		        	
		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }  
		return pointdate;    	
     }
	
	/** Extract the name of each day and returns an array*/
	public String[] getOneDateName(int days) throws IOException 
	{	
		//Declare number of day
		int day=0+days;
		//Declare y
		String z = "";
		//array declaration
		String[] onedate = null;
		//The element of the array pointdate are obtained with the method getNumberPoint*getNumberDay
		onedate = new String[getNumberPoint()];	
		//Declare number of the line
		int nline = 0;
		//Array index
		int i = 0;	
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		       
			   	//create string line
		        String line = br.readLine();
		
		        while (line != null) 
		        {		         
		            line = br.readLine();
		        	nline++;
		        	if( nline>(5+( (1+day)*getNumberPoint() )) & nline < ( 7+ ((1+day)*getNumberPoint()) + (getNumberPoint()-1) ) )
		        	{	        	
		        	String npoint[] = line.split(",");
		        	// convert the string to double
		            z =npoint[0];
		            onedate[i] = z;		            
		            i++;	  

		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   } 
		return onedate;
	}

	
	/** Extract the y position from csv file ad returns a double*/
	public double[]  getCsvY() throws IOException 
	{	
		//Declare y
		double y = 0.0;
		//array declaration
		double[] ypoint = null;
		//The element of the array pointname are obtained with the method getNumberPoint
		ypoint = new double[getNumberPoint()];	
		//Declare number of the line
		int nline = 0;
		//Array index
		int i = 0;	
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		       
			   	//create string line
		        String line = br.readLine();
		
		        while (line != null) 
		        {		         
		            line = br.readLine();
		        	nline++;
		        	if( nline>=(5+getNumberPoint()) & nline < (5+(2*getNumberPoint())) )
		        	{	        	
		        	String npoint[] = line.split(",");
		        	// convert the string to double
		            y = Double.parseDouble(npoint[1]);
		            ypoint[i] = y;
		            i++;
		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }   
		return ypoint;
	}
	
	/** Extract the x position from csv file ad returns a double*/
	public double[] getCsvX() throws IOException 
	{	
		//Declare y
		double x = 0.0;
		//array declaration
		double[] xpoint = null;
		//The element of the array pointname are obtained with the method getNumberPoint
		xpoint = new double[getNumberPoint()];	
		//Declare number of the line
		int nline = 0;
		//Array index
		int i = 0;	
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		       
			   	//create string line
		        String line = br.readLine();
		
		        while (line != null) 
		        {		         
		            line = br.readLine();
		        	nline++;
		        	if( nline>=(5+getNumberPoint()) & nline < (5+(2*getNumberPoint())) )
		        	{	        	
		        	String npoint[] = line.split(",");
		        	// convert the string to double
		            x = Double.parseDouble(npoint[0]);
		            xpoint[i] = x;
		            i++;
		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }		      
		return xpoint;
	}


	
	/**Extract all z value (pollution value) from csv file and returns a double*/
	public double[]  getCsvZ() throws IOException 
	{	
		//Declare y
		double z = 0.0;
		//array declaration
		double[] zpoint = null;
		//The element of the array point date are obtained with the method getNumberPoint*getNumberDay
		zpoint = new double[getNumberPoint()*getNumberDay()];	
		//Declare number of the line
		int nline = 0;
		//Array index
		int i = 0;	
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		       
			   	//create string line
		        String line = br.readLine();
		
		        while (line != null) 
		        {		         
		            line = br.readLine();
		        	nline++;
		        	if( nline>=(6+(2*getNumberPoint())) & nline < (6+(2*getNumberPoint())+(getNumberPoint()*getNumberDay())) )
		        	{	        	
		        	String npoint[] = line.split(",");
		        	// convert the string to double
		            z = Double.parseDouble(npoint[1]);
		            zpoint[i] = z;
		            i++;
		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }
		return zpoint;
	}
	
	/**Extract the z value for each day (pollution value) and returns a double*/
	public double[]  getCsvZD(int days) throws IOException 
	{	
		//Declare number of day OVVERO 0+N
		int day=0+days;
		//Declare y
		double z = 0.0;
		//array declaration
		double[] zpoint = null;
		//The element of the array pointdate are obtained with the method getNumberPoint*getNumberDay
		zpoint = new double[getNumberPoint()];	
		//Declare number of the line
		int nline = 0;
		//Array index
		int i = 0;	
		//Create buffer reader	
		BufferedReader br = new BufferedReader(new FileReader(ShpLoader3D.url2));
		   try 
		   {		       
			   	//create string line
		        String line = br.readLine();
		
		        while (line != null) 
		        {		         
		            line = br.readLine();
		        	nline++;
		        	if( nline>(5+( (1+day)*getNumberPoint() )) & nline < ( 7+ ((1+day)*getNumberPoint()) + (getNumberPoint()-1) ) )
		        	{	        	
		        	String npoint[] = line.split(",");
		        	// convert the string to double
		            z = Double.parseDouble(npoint[1]);
		            zpoint[i] = z;
		            
		            i++;	  
		            }		        	
		        }
		   } 
		   finally 
		   {
			   br.close();
		   }  
		return zpoint;
	}	
	
	
	public static void main(String[] args) throws IOException {
	}
}
