package gov.nasa.worldwindx.examples.csvairquality;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * This class has been adapted to apply the Delaunay triangulations, to points read from csv. 
 * @author  Data processor Marco Piragnolo Cirgeo, University of Padua, marco.piragnolo@unipd.it. Original class by Geoff Leach gl@cs.rmit.edu.au 29/3/96.
 * @version 0.1 TriangulationPackeage 2013-21-05 13:24
 * 
 * */

import gov.nasa.worldwind.geom.Vec4;

import java.awt.*;
import java.util.*;
import java.lang.Math;
import java.io.IOException;


import gov.nasa.worldwind.geom.Triangle;

/**This class performs a Delaunay triangulation */
public class TriangulationPackage {
	static int np = 0;
    double crossProduct(RealPoint p1, RealPoint p2, RealPoint p3) { 
		double u1, v1, u2, v2;
	
		u1 =  p2.x() - p1.x();
		v1 =  p2.y() - p1.y();
		u2 =  p3.x() - p1.x();
		v2 =  p3.y() - p1.y();		
		return u1 * v2 - v1 * u2;
    }
    
  
    /**Manage error*/
	static public  class Error {
	    static public void error(String m) {
		System.err.println(m);
		System.exit(1);
	    }
	}

	 /** Point class.  RealPoint to avoid clash with java.awt.Point.*/
	class RealPoint {
	    double x, y;
	
	    RealPoint() { x = y = 0.0f; }
	    RealPoint(double x, double y) { this.x = x; this.y = y; }
	    RealPoint(RealPoint p) { x = p.x; y = p.y; }
	    public double x() { return this.x; }
	    public double y() { return this.y; }
	    public void set(double x, double y) { this.x = x; this.y = y; }
	
	    public double distance(RealPoint p) {
		double dx, dy;
	
		dx = p.x - x;
		dy = p.y - y;
		return (float)Math.sqrt((double)(dx * dx + dy * dy));
	    }
	
	    public double distanceSq(RealPoint p) { 
		double dx, dy;
	
		dx = p.x - x;
		dy = p.y - y;
		return (float)(dx * dx + dy * dy);
	    }
	}

	/** 
	 * Edge class. Edges have two vertices, s and t, and two faces,
	 * l (left) and r (right). The Delaunay triangulation algorithms require edges.
	 */
	class Edge {
	    int s, t;
	    int l, r;
	
	    Edge() { s = t = 0; }
	    Edge(int s, int t) { this.s =s; this.t = t; }
	    int s() { return this.s; }
	    int t() { return this.t; }
	    int l() { return this.l; }
	    int r() { return this.r; }
	}


	
	/**Vector class for Delaunay triangulation*/
	public static class Vector {
	   static double crossProduct(RealPoint p1, RealPoint p2, RealPoint p3) { 
			double u1, v1, u2, v2;
		
			u1 =  p2.x() - p1.x();
			v1 =  p2.y() - p1.y();
			u2 =  p3.x() - p1.x();
			v2 =  p3.y() - p1.y();
		
			return u1 * v2 - v1 * u2;
	    }
	    double u, v;
	
	    Vector() { u = v = 0.0f; }
	    Vector(RealPoint p1, RealPoint p2) { 
		u = p2.x() - p1.x(); 
		v = p2.y() - p1.y(); 
	    }
	    Vector(double u, double v) { this.u = u; this.v = v; }
	
	    double dotProduct(Vector v) { return u * v.u + this.v * v.v; }
	
	     double dotProduct(RealPoint p1, RealPoint p2, RealPoint p3) { 
			double u1, v1, u2, v2;
		
			u1 =  p2.x() - p1.x();
			v1 =  p2.y() - p1.y();
			u2 =  p3.x() - p1.x();
			v2 =  p3.y() - p1.y();
		
			return u1 * u2 + v1 * v2;
	    }
	}

	/**
	 * Circle class. Circles are fundamental to computation of Delaunay 
	 * triangulations.  In particular, an operation which computes a 
	 * circle defined by three points is required.
	 */
	class Circle {
	    RealPoint c;
	    double r;
	
	    Circle() { c = new RealPoint(); r = 0.0f; }
	    Circle(RealPoint c, double r) { this.c = c; this.r = r; }
	    public RealPoint center() { return c; }
	    public double radius() { return r; }
	    public void set(RealPoint c, double r) { this.c = c; this.r = r; }
	
	    /** 
	     * Tests if a point lies inside the circle instance.
	     */
	    public boolean inside(RealPoint p) {
		if (c.distanceSq(p) < r * r)
		    return true;
		else
		    return false;
	    }
	
	    /** 
	     * Compute the circle defined by three points (circumcircle). 
	     */
	    public void circumCircle(RealPoint p1, RealPoint p2, RealPoint p3) {
		double cp;
	
		cp = Vector.crossProduct(p1, p2, p3);
		if (cp != 0.0)
		    {
			double p1Sq, p2Sq, p3Sq;
			double num;
			double cx, cy;
	
			p1Sq = p1.x() * p1.x() + p1.y() * p1.y();
			p2Sq = p2.x() * p2.x() + p2.y() * p2.y();
			p3Sq = p3.x() * p3.x() + p3.y() * p3.y();
			num = p1Sq*(p2.y() - p3.y()) + p2Sq*(p3.y() - p1.y()) + p3Sq*(p1.y() - p2.y());
			cx = num / (2.0f * cp);
			num = p1Sq*(p3.x() - p2.x()) + p2Sq*(p1.x() - p3.x()) + p3Sq*(p2.x() - p1.x());
			cy = num / (2.0f * cp);
	
			c.set(cx, cy);
		    }    
		// Radius 
		r = c.distance(p1);
	    }
	}
 
	/**
	 * Triangulation class.  A triangulation is represented as a set of
	 * points and the edges which form the triangulation.
	 */
	public class Triangulation {
	 
		static final int Undefined = -1;
	    static final int Universe = 0;
	    int nPoints;
	    int triangles[]; //array of triangles
	    RealPoint point[];
	    double valoreZ[]; //z value
	    int nEdges;
	    int maxEdges;
	    Edge edge[]; 
	    ArrayList<Triangle> mTriangles;
	    int nTriangles;
	
	    Triangulation(int nPoints) {
	    	nTriangles=0;
	    	mTriangles = new ArrayList<Triangle>();
	    	valoreZ = new double[nPoints];
			// Allocate points. 
			this.nPoints = nPoints;
			this.point = new RealPoint[nPoints];
			for (int i = 0; i < nPoints; i++)
			    point[i] = new RealPoint();
		
			// Allocate edges. 
			maxEdges = 3 * nPoints - 6;	// Max number of edges.
			edge = new Edge[maxEdges];
			for (int i = 0; i < maxEdges; i++)
			    edge[i] = new Edge();
			nEdges = 0;
	    }

	    /** 
	     * Generates a set of random points to triangulate. 
	     */
	    public void randomPoints(RealWindow w) {
		for (int i = 0; i < nPoints; i++)
		    {
			point[i].x = (float)Math.random() * w.xMax();
			point[i].y = (float)Math.random() * w.yMax();	
		    }
		nEdges = 0;
	    }
	     
	    //Get the points from csv to generate triangulate.  
	    public void putMyPoints() {
		for (int i = 0; i < np; i++)
		    {
			CsvEmReader csv = new CsvEmReader();
			//get the x value from csv
			double x[] = null;
			try {
				x = csv.getCsvX();
			} catch (IOException e) {
				e.printStackTrace();
			}
			double y[] = null;
			try {
			//get the y value from csv
				y = csv.getCsvY();
			} catch (IOException e) {
				e.printStackTrace();
			}
			point[i].x = (float) x[i];
			point[i].y = (float) y[i];
		    }
		nEdges = 0;
	    }
	
	    void addTriangle(int s, int t, int u) {
		addEdge(s, t);
		addEdge(t, u);
		addEdge(u, s);
	    }
	
	    public int addEdge(int s, int t) {
		return addEdge(s, t, Undefined, Undefined);
	    }
	
	     
	    /** Adds an edge to the triangulation. Store edges with lowest vertex first (easier to debug and makes no other difference).*/
	   	public int addEdge(int s, int t, int l, int r) {
		int e;
	
		/** Add edge if not already in the triangulation.*/
		e = findEdge(s, t);
		if (e == Undefined) 
		    if (s < t)
			{
			    edge[nEdges].s = s;
			    edge[nEdges].t = t;
			    edge[nEdges].l = l;
			    edge[nEdges].r = r;
			    return nEdges++;
			} 
		    else
			{
			    edge[nEdges].s = t;
			    edge[nEdges].t = s;
			    edge[nEdges].l = r;
			    edge[nEdges].r = l;
			    return nEdges++;
			}
		else
		    return Undefined;
	    }
	
	    public int findEdge(int s, int t) {
		boolean edgeExists = false;
		int i;
	
		for (i = 0; i < nEdges; i++)
		    if (edge[i].s == s && edge[i].t == t || 
			edge[i].s == t && edge[i].t == s) {
			edgeExists = true;
			break;
		    }
	
		if (edgeExists)
		    return i;
		else
		    return Undefined;
	    }
	
	    
	    /**Update the left face of an edge.*/
	    public void updateLeftFace(int eI, int s, int t, int f) {
		if (!((edge[eI].s == s && edge[eI].t == t) ||
		      (edge[eI].s == t && edge[eI].t == s)))
		    Error.error("updateLeftFace: adj. matrix and edge table mismatch");
		if (edge[eI].s == s && edge[eI].l == Triangulation.Undefined)
		    edge[eI].l = f;
		else if (edge[eI].t == s && edge[eI].r == Triangulation.Undefined)
		    edge[eI].r = f;
		else
		    Error.error("updateLeftFace: attempt to overwrite edge info");
	    }
	}
 
	/**Rectangle class.  Need rectangles for window to viewport mapping.*/
	public class RealRectangle {
	    RealPoint ll;
	    RealPoint ur;
	
	    RealRectangle() { }
	
	    RealRectangle (RealRectangle r) {
		this.ll = new RealPoint(r.ll);
		this.ur = new RealPoint(r.ur);
	    }
	
	    RealRectangle (RealPoint ll, RealPoint ur) {
		this.ll = new RealPoint(ll);
		this.ur = new RealPoint(ur);
	    }
	
	    RealRectangle(double xMin, double yMin, double xMax, double yMax) {
		this.ll = new RealPoint(xMin, yMin);
		this.ur = new RealPoint(xMax, yMax);
	    }
	
	    public double width() { return ur.x() - ll.x(); }
	    public double height() { return ur.y() - ll.y(); }
	
	    public RealPoint ll() { return ll; }
	    public RealPoint ur() { return ur; }
	
	    public double xMin() { return ll.x; }
	    public double yMin() { return ll.y; }
	
	    public double xMax() { return ur.x; }
	    public double yMax() { return ur.y; }
	}

	 
	 /**A window is  a rectangle.*/	 
	class RealWindow extends RealRectangle {
	    RealWindow() {}
	    RealWindow(double xMin, double yMin, double xMax, double yMax) {
		super(xMin, yMin, xMax, yMax); 
	    }
	    RealWindow(RealWindow w) { super(w.ll(), w.ur()); }
	}

	
	/**This class has a window, a viewport*/
	class RealWindowGraphics {
	    RealWindow w = null;	// window
	    Dimension v = null;	// viewport
	    Graphics g = null;
	    double scale = 1.0f;
	
	    static final double realPointRadius = 0.04f;
	    static final int pixelPointRadius = 4;
	    static final int halfPixelPointRadius = 2;
	}



	
	 /**Has several abstract function members including the triangulation member which actually computes the triangulation*/
	abstract class TriangulationAlgorithm {
		String algName;
	
	    RealWindow w;
	    RealWindowGraphics rWG;
	
	    // Variables and constants for animation state. 
	    final int nStates = 5;
	    boolean state[] = new boolean[nStates];
	    static final int triangulationState = 0;
	    static final int pointState = 1;
	    static final int triangleState = 2;
	    static final int insideState = 4;
	    static final int edgeState = 5;
	
	    public TriangulationAlgorithm(Triangulation t, RealWindow w, 
					  String name, int nPoints) {
		algName = name;
	
		for (int s = 0; s < nStates; s++)
		    state[s] = false;
	    }
			
	    public void reset() {
	    	for (int s = 0; s < nStates; s++)
	    	    state[s] = false;
	        }	
	}
	

	/**QuarticAlgorithm class.  O(n^4) algorithm. The most brute-force*/
	class QuarticAlgorithm extends TriangulationAlgorithm {
	    int i, j, k, l;
	    Circle c = new Circle();
	    final static String algName = "O(n^4)";
	
	    public QuarticAlgorithm(Triangulation t, RealWindow w, int nPoints) {
		super(t, w, algName, nPoints);
	    }
	
	    public void reset() {
		i = j = k = l = 0;
		super.reset();
	    }
	
	    public synchronized void triangulate(Triangulation t) {
		boolean pointFree;
		int n = t.nPoints;
		RealPoint p[] = t.point;
	
		for (i = 0; i < n-2; i++)
		    for (j = i + 1; j < n-1; j++)
			if (j != i)
			    for (k = j + 1; k < n; k++)
				if (k != i && k != j)
				    { 
					c.circumCircle(p[i], p[j], p[k]);
					pointFree = true;
					for (l = 0; l < n; l++)
					    if (l != i && l != j && l != k) {
							if (c.inside(p[l])) {
							    pointFree = false;
							    break;
							}
					    }	
						if (pointFree){
						    t.addTriangle(i, j, k);
						    Vec4 vv1 = new Vec4( p[i].x, p[i].y, t.valoreZ[i]);
						    Vec4 vv2 = new Vec4( p[j].x, p[j].y, t.valoreZ[j]);
						    Vec4 vv3 = new Vec4( p[k].x, p[k].y, t.valoreZ[k]);
				    	
						    t.mTriangles.add( new Triangle(vv1,vv2,vv3) );
						    t.nTriangles++;
						}
				    }
	    }
	}
}

