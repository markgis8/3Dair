package gov.nasa.worldwindx.examples.csvairquality;

import gov.nasa.worldwind.formats.shapefile.Shapefile;
import gov.nasa.worldwind.formats.shapefile.ShapefileRecord;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwind.util.VecBuffer;
import gov.nasa.worldwind.layers.Layer;
import java.util.ArrayList;
import java.util.List;


/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * 
 * This class extrudes polygon from a shape file
 * The default value of 1. 
 * The default column is UN_VOL_AV but you can specify another column
 * @author Marco Piragnolo Cirgeo, University of Padua, marco.piragnolo@unipd.it
 * @version 0.1 CsvEmReader 2013-21-05 12:53
 */

/** Extrudes the polygon from a shape layer*/
public class ShpLayer {
	protected gov.nasa.worldwindx.examples.csvairquality.ShpLoader3D.AppFrame appFrame;

	public List<Layer> shpLayer(Object source, String colname) {

		// Create the layer where you will place your polygons
		RenderableLayer layer = new RenderableLayer();
		// Create new shapefile
		Shapefile shapeFile = new Shapefile(source);
		// Setting attributes for the loaded shapefile
		ShapeAttributes normalAttributes = new BasicShapeAttributes();
		normalAttributes.setInteriorMaterial(Material.WHITE);
		normalAttributes.setInteriorOpacity(0.5);
		normalAttributes.setOutlineWidth(1);
		ShapefileRecord record;
		VecBuffer vectorBuffer;

		ExtrudedPolygon polygon;
		// Performing a loop into the shapefile to get all its polygons
		while (shapeFile.hasNext()) {
			// Reading the shapefile current record and storing in a temporary variable of the type ShapefileRecord
			record = shapeFile.nextRecord();
			vectorBuffer = record.getPointBuffer(0);
			double colheight = 0;
			// Setting height
			if (colname.isEmpty() == true
					&& record.getAttributes().getValue("UN_VOL_AV") != null) {
				// the Shapefile have UN_VOL_AV column and it uses this value
				colheight = (Double) record.getAttributes().getValue(
						"UN_VOL_AV");
			} else if (colname.isEmpty() == true) {
				// If the Shapefile haven't UN_VOL_AV column, it's used a default value 1 
				colheight = 1;
			} else {
				// the user has specified another column
				colheight = (Double) record.getAttributes().getValue(colname);
			}

			// Creating an instance of ExtrudedPolygon
			polygon = new ExtrudedPolygon();
			// Setting the polygon outer boundary bases on the current shapefile record
			polygon.setOuterBoundary(vectorBuffer.getLocations(), colheight);
			// Setting polygon attributes
			polygon.setAttributes(normalAttributes);
			// Attaching the polygon to a layer
			layer.addRenderable(polygon);
		}
		// Closing shape file
		shapeFile.close();
		List<Layer> layers = new ArrayList<Layer>();
		layers.add(layer);
		return layers;
	}

	/**Gets the central position latitude*/
	public double getCentreLat(Object source)
	{
		Shapefile coordinates = new Shapefile(source);
		//System.out.println("minlat: " + coordinates.getBoundingRectangle()[0]);
		//System.out.println("maxlat: " + coordinates.getBoundingRectangle()[1]);
		double centreLat = (coordinates.getBoundingRectangle()[0] + coordinates
				.getBoundingRectangle()[1]) / 2;
		coordinates.close();
		return centreLat;
	}

	/**Gets the central position  longitude*/
	public double getCentreLon(Object source) 
	{
		Shapefile coordinates = new Shapefile(source);
		//System.out.println("minlon: " + coordinates.getBoundingRectangle()[2]);
		//System.out.println("maxlon: " + coordinates.getBoundingRectangle()[3]);
		double centreLon = (coordinates.getBoundingRectangle()[2] + coordinates
				.getBoundingRectangle()[3]) / 2;
		coordinates.close();
		return centreLon;
	}
	
	/**Gets the length of the base in order to calculate the height of point of view*/
	public double getShpBase(Object source) 
	{
		Shapefile coordinates = new Shapefile(source);
		LatLon p1 = LatLon.fromDegrees(coordinates.getBoundingRectangle()[0],
				coordinates.getBoundingRectangle()[2]);
		LatLon p2 = LatLon.fromDegrees(coordinates.getBoundingRectangle()[1],
				coordinates.getBoundingRectangle()[3]);
		double lenght = LatLon.ellipsoidalDistance(p1, p2, 6378.1, 6356.8) * 1000; 																			
		coordinates.close();
		return lenght;
	}

	public static void main(String[] args) {

	}

}
